// SecureCodingModule1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//#include <iostream>
//#include <limits>
//
//
//void swapFnc(int* a, int* b)
//{
//    if (*a < *b)
//    {
//        int temp = *a;
//        *a = *b;
//        *b = temp;
//    }
//}
//bool testAddition(int a, int b)
//{
//    //overflow
//    if ((a > 0 && b > 0 && a > std::numeric_limits<int>::max() - b))
//    {
//        return true;
//    }
//    //underflow
//    else if ((a < 0 && b < 0 && a < std::numeric_limits<int>::min() - b))
//    {
//        return true;
//    }
//    else
//    {
//        return false;
//    }
//}
//
//bool testSubtraction(int a, int b)
//{
//    //swapFnc(a, b);
//    //overflow
//    if (b < 0 && a > std::numeric_limits<int>::max() + b)
//    {
//        return true;
//    }
//    //underflow
//    else if (b > 0 && a < std::numeric_limits<int>::min() + b)
//    {
//        return true;
//    }
//    else
//    {
//        return false;
//    }
//}
//static void alertOverflowUnderFlowAddition(int no1, int no2)
//{
//    int sum = no1 + no2;
//    bool isOverflow = testAddition(no1, no2);
//    if (!isOverflow)
//    {
//        std::cout << "Addition overflow/underflow does not occur!" << std::endl;
//        std::cout<<"The result of the addition is " << sum << std::endl;
//    }
//    else {
//        std::cout << "Addition overflow/underflow does occur!" << std::endl;
//    }
//}
//static void alertOverflowUnderFlowSubtraction(int no1, int no2)
//{
//    int diff = no1 - no2;
//    bool isOverflow = testSubtraction(no1, no2);
//    if (!isOverflow)
//    {
//        std::cout << "Subtraction overflow or underflow does not occur!" << std::endl;
//        std::cout << "The result of the subtraction is " << diff << std::endl;
//    }
//    else {
//        std::cout << "Subtraction overflow or underflow does occur!" << std::endl;
//    }
//}
//int main()
//{
//    //std::cout << "Size of int " << sizeof(int) * 8 << std::endl;
//    int a,b,c,d;
//     a = 789;
//     b = 85;
//     c = -1;
//     d = -2147483648;
//    alertOverflowUnderFlowAddition(c, d);
//    //swapFnc(&c, &d); 
//    
//    alertOverflowUnderFlowSubtraction(c, d);
//    return 0;
//}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
