﻿// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_order
	//  varaible, and its position in the declaration. It must always be directly before the variable used for input.

	//Defining variables
	const std::string account_number = "CharlieBrown42";
	std::string user_input;
	const size_t maxLength = 20; // Maximum allowed length for input

	//Get user inputs
	std::cout << "Enter a value: ";
	std::getline(std::cin, user_input);

	//use length of user input to detect buffer overflow
	if (user_input.length() > maxLength)
	{
		std::cerr << "Error: Input exceeds the maximum allowed length of 20 characters." << std::endl;
		std::cerr << "Restart program!" << std::endl;
		return 1;
	}
	else if (!user_input.empty() && user_input.length() <= 20)
	{
		std::cout << '\n' << std::endl;
		std::cout << "SUCCESSFUL ENTRY !!!" << std::endl;
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}
	else
	{
		std::cout << "Empty String. Restart program!" << std::endl;
	}
}
